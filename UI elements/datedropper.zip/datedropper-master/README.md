# datedropper
datedropper is a jQuery plugin that provides a quick and easy way to manage dates for input fields.


[Usage and Examples](http://bit.ly/17ab6dt)
