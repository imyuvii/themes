CHANGELOG
=========

This changelog references the relevant changes and bug fixes done.

* 1.1.2 & 1.1.3(2014-06-11)
  * yago31 : Fix search with the last Hologram update

* 1.1.1 (2014-05-08)
  * yago31 : Update how to install hologram in the README
  * yago31 : fix few little css things

* 1.1.0 (2014-05-07)
  * yago31 : fix many bootstrap conflict with theme
  * yago31 : enhance theme with a complete color scheme change
  * yago31 : add search feature
  * yago31 : add css/js to include in the hologra_config.yml
  * yago31 : add scope_name option

* 1.0.2 (2014-04-23)
  * yago31 : fix bower ignore

* 1.0.1 (2014-04-23)
  * yago31 : add License and bower ignore

* 1.0.0 (2014-04-23)
  * yago31 : After one little week, Cortana finally come to a stable and usable version.
