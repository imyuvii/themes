'use strict';

(function () {

  //import("pathformer.js");
  //import("vivus.js");

  window.Vivus = Vivus;
}());
